-- EXAMPLE DATABSE 

CREATE DATABASE test;

CREATE TABLE1 (id int(11), name varchar(200));


