<?php
/***************************************
 * Author: 		Armando Padilla 
 * Page:  		ClassFactory.class.php
 * Description: Creates the class files.
 *              PHP 4 Solution ONLY.
 * Date:        4/17/2007
 *=======================================
 * Update Info:  
 *
 *
 ***************************************/
class ClassFactory {


	var $tableColumns;  //Keeps track of all the columns in the table.
	

	function ClassFactory(){}
		
	/**********************************
	 * create:     Creates a new file based on the table name specified
	 * Parameters: (String) Table Name
	 * Return:     (Boolean) True - File created successfully | False - File was not created.
	 **********************************/
	function create($tableName, $tableInfo){
	
		$tableName[0] = strtoupper($tableName[0]);
		
		if($fh = fopen($tableName.".class.php", "w")){
			
			//CAPTURE ALL THE COLUMNS FOR LATER USE.
			$this->tableColumns = $this->getColumns($tableInfo);
			
			//Create the attribute section
			$attributes = $this->addAttributes($this->tableColumns);
			
			//Create the methods section
			$add		= $this->addAddMethod($tableName, $this->tableColumns);
			$delete     = $this->addDeleteMethod($tableName);
			$update		= $this->addUpdateMethod($tableName);
			$getAll	    = $this->addGetAllMethod($tableName, $this->tableColumns);
			$getObject	= $this->addGetObjectMethod($tableName, $this->tableColumns);
			
			//Stick it together.
			$string  = "<?php\n";
			$string .= "/******************************************\n";
			$string .= " * Author: <YOUR NAME HERE>\n";
			$string .= " * Description: <YOUR DESCRIPTION HERE>\n";
			$string .= " ******************************************/\n";
			$string .= "class ".$tableName." { \n\n";
			$string .= "	var \$db; \n";
			$string .= $attributes."\n";
			$string .= "	function ".$tableName."(\$db){ \n";
			$string .= "          \$this->db = \$db; \n";
			$string .= "    }\n\n"; 
			$string .= $add;
			$string .= $delete;
			$string .= $update;
			$string .= $getAll;
			$string .= $getObject;
			$string .= "}//End Class ".$tableName."\n";
			$string .= "?>";
			
			
			//Write the file
			if(fwrite($fh, $string)){
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}
		
	}//End new()
	
	
	/**********************************
	 * GetColumns:   Places all the columns into an array for later use
	 * Parameters:   (Array of String) TableColumn Information.
	 * Return:       Array
	 **********************************/
	function getColumns($tableInfo){
	
		$container = array();
		foreach($tableInfo as $table){
		
			array_push($container, $table['name']);
		
		}//End foreach
		
		return $container;
	
	}//End
	
	/**********************************
	 * AddAttributes:   Places all the column name as attributes in the class.
	 * Parameters:      (Array of String) TableColumns
	 * Return:          oidV
	 **********************************/
	function addAttributes($tableColumns){
	
		foreach($tableColumns as $column){
		
			$string .= "	var \$".$column.";\n"; 
		
		}//End foreach
		
		return $string;
	
	}//End
	
	
	/*******************************
	 * addAddMethod:  Creates the insert statment for the table. Will be called 'add'
	 * Parameters:   (String) Table Name | (Array of Strings) Table Columns
	 * Return:        N/A
	 *******************************/
	function addAddMethod($tableName, $tableColumns){
	
	
		//Create parameters
		foreach($tableColumns as $column){
			$parameters .= "'\$".$column."', "; 
		}//End foreach
		$parameters = rtrim($parameters, ", ");
		
		//Create the column Names
		foreach($tableColumns as $column){
			$columnNames .= "".$column.", "; 
		}//End foreach
		$columnNames = rtrim($columnNames, ", ");
		
	
		$string  = "	/***********************************\n";
		$string .= " 	 * Add:         Allows the insertion of values into the Table.\n";
		$string .= " 	 * Parameters:  ".str_replace("'", "", $parameters)."\n";
		$string .= " 	 * Return:      (Boolean) True - Successfully Inserted | False - Error\n";
		$string .= " 	 ************************************/\n";
		$string .= "	function add(".str_replace("'", "", $parameters)."){ \n\n";
		
		$string .= "		//Custom SQL Injection Escaping HERE\n\n";
		$string .= "		\$statement = \"INSERT INTO ".$tableName." (".$columnNames.") VALUES (".$parameters.");\";\n";
		$string .= "		\$results   = \$this->db->query(\$statement);\n\n";
		$string .= "		if(\$results){\n";
		$string .= "			return true;\n";
		$string .= "		}else{\n";
		$string .= "			return false;\n";
		$string .= "		}\n\n";
		$string .= "	}//End add()\n\n\n";
		
		return $string;
			
	}
	
	
	/*******************************
	 * addRemoveMethod:  Creates the delete statment for the table. Will be called 'remove'
	 * Parameters:   (String) Table Name
	 * Return:        N/A
	 *******************************/
	function addDeleteMethod($tableName){
	
		$string  = "	/***********************************\n";
		$string .= " 	 * Remove:      Allows for the removal of record from the database.\n";
		$string .= " 	 * Parameters:  (String)Primary Key Column Name | (Int) Primary Key Value\n";
		$string .= " 	 * Return:      (Boolean) True - Successfully Removed | False - Error\n";
		$string .= " 	 ************************************/\n";
		$string .= "	function remove(\$primaryKeyName, \$primaryKeyValue){ \n\n";
		
		$string .= "		//Custom SQL Injection Escaping HERE\n\n";
		$string .= "		\$statement = \"DELETE FROM ".$tableName." WHERE \$primaryKeyName = '\$primaryKeyValue'\";\n";
		$string .= "		\$results   = \$this->db->query(\$statement);\n";
		$string .= "		if(\$results){\n";
		$string .= "			return true;\n";
		$string .= "		}else{\n";
		$string .= "			return false;\n";
		$string .= "		}\n\n";
		$string .= "	}//End remove()\n\n\n";
		
		return $string;
	
	}//End addDeleteMethod()
	
	
	/*******************************
	 * addUpdateMethod:  Creates the update statment for the table. Will be called 'update'
	 * Parameters:      (String) Table Name
	 * Return:           N/A
	 *******************************/
	function addUpdateMethod($tableName){
	
		$string  = "	/***********************************\n";
		$string .= " 	 * Update:      Allows for the update of a record from the database.\n";
		$string .= " 	 * Parameters:  (String)Primary Key Column Name | (Int) Primary Key Value | (String) Column Name To Update | (String) New Value\n";
		$string .= " 	 * Return:      (Boolean) True - Successfully Updated | False - Error\n";
		$string .= " 	 ************************************/\n";
		$string .= "	function update(\$primaryKeyName, \$primaryKeyValue, \$columnNameToUpdate, \$columnValue){ \n\n";
		
		$string .= "		//Custom SQL Injection Escaping HERE\n\n";
		$string .= "		\$statement = \"UPDATE ".$tableName." SET \$columnNameToUpdate = '\$columnValue' WHERE \$primaryKeyName = '\$primaryKeyValue'\";\n";
		$string .= "		\$results   = \$this->db->query(\$statement);\n";
		$string .= "		if(\$results){\n";
		$string .= "			return true;\n";
		$string .= "		}else{\n";
		$string .= "			return false;\n";
		$string .= "		}\n\n";
		$string .= "	}//End update()\n\n\n";
	
		return $string;
	
	}//End addUpdateMethod

	/*******************************
	 * addGetAllMethod:  Creates the method that returns all records in the database.
	 * Parameters:       (String) Table Name | (Array of Strings) Table Columns
	 * Return:           N/A
	 *******************************/
	function addGetAllMethod($tableName, $tableColumns){
	
		
		//Create the column Names
		foreach($tableColumns as $column){
			$columnNames .= "".$column.", "; 
		}//End foreach
		$columnNames = rtrim($columnNames, ", ");
		
		
		$string  = "	/***********************************\n";
		$string .= " 	 * GetAll:       Returns all the records in the database.\n";
		$string .= " 	 * Parameters:   NA\n";
		$string .= " 	 * Return:      (MultiDimensional-Array)String\n";
		$string .= " 	 ************************************/\n";
		$string .= "	function getAll(){ \n\n";
		$string .= "		//Custom SQL Injection Escaping HERE\n\n";
		$string .= "		\$statement = \"SELECT ".$columnNames." FROM ".$tableName."\";\n";
		$string .= "		\$results   = \$this->db->getAll(\$statement);\n\n";
		$string .= "		return \$results;\n\n";
		
		$string .= "	}//End getAll()\n\n\n";
		
		return $string;
		
	
	}//End addGetAllMethod()

	
	/*******************************
	 * addGetObjectMethod:  Creates the method that returns a specific record from the database.
	 * Parameters:         (String) Primary Key Value
	 * Return:             (Array) String
	 *******************************/
	function addGetObjectMethod($tableName, $tableColumns){
	
		//Create the column Names
		foreach($tableColumns as $column){
			$columnNames .= "".$column.", "; 
		}//End foreach
		$columnNames = rtrim($columnNames, ", ");
		
		
		$string  = "	/***********************************\n";
		$string .= " 	 * GetObject:   Returns a specific record form the batabase.\n";
		$string .= " 	 * Parameters:  (Int) Primary Key Value\n";
		$string .= " 	 * Return:      (Array)String\n";
		$string .= " 	 ************************************/\n";
		$string .= "	function getObject(\$primaryKeyName, \$primaryKeyValue){ \n\n";
		$string .= "		//Custom SQL Injection Escaping HERE\n\n";
		$string .= "		\$statement = \"SELECT ".$columnNames." FROM ".$tableName." WHERE \".\$primaryKeyName.\" = '\".\$primaryKeyValue.\"'\";\n";
		$string .= "		\$results   = \$this->db->getAll(\$statement);\n\n";
		$string .= "		return \$results;\n\n";
		$string .= "	}//End getObject()\n\n\n";
		
		return $string;
		
	}//End addGetObjectMethod()
	
	
}//End class
?>