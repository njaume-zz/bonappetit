<?php
/***********
 * Author: Armando Padilla, www.armando.ws
 * Description: Simple Example on how to use Singleton classes created
 *              by scaffold4php.
 ***********/
require_once("Table1.class.php");
require_once("DB.php");
require_once("DB/common.php");

/******
 * YOUR DB CONN INFO
 * Usually this is in an include and all you have 
 * to do is instantiate the a DB constructor.
 * DB PEAR library recommended.
 ******/
$connectionString = array(
						    'phptype'  => "mysql",
						    'hostspec' => "localhost",
						    'database' => "test",
						    'username' => "root",
						    'password' => ""
						);

$db = DB::connect($connectionString);
if(PEAR::isError($db)){
	echo "Could not connect to requested database<br>";
	//print_r($db);  //Uncomment for debugging
	exit();
}

/******
 * INITIALIZE CLASS
 ******/
$Table1 = new Table1($db);

/******
 * CREATE A NEW RECORD
 ******/
$Table1->add('3', 'armando padilla');  

/******
 * UPDATE NEWLY ADDED RECORD
 ******/
$Table1->update("id", "3", "name", "armando padilla - updated");

/******
 * GET DATA FOR ABOVE USER
 ******/
$recordObj = $Table1->getObject("id", "3");

echo "<pre>";
print_r($recordObj);  //View the ouput array.
echo "</pre>";

/******
 * GET ALL THE RECORDS IN THE DB TABLE
 ******/
$records = $Table1->getAll();

echo "<pre>";
print_r($records); //View the ouput array.
echo "</pre>";

/*****
 * DELETE THE RECORD
 *****/
$Table1->remove("id", "3");
?>