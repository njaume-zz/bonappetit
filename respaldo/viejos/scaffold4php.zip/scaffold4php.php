<?php
/***************************************
 * Author: 		Armando Padilla 
 * Page:  		Scaffold4PHP.php
 * Description: Creates Classes for all Tables inside a given database.
 *              PHP 5 Solution ONLY.
 * Date:        4/17/2007
 *=======================================
 * Update Info:  
 *
 *
 ***************************************/
require_once("DB.php");
require_once("DB/common.php");
require_once("ClassFactory.class.php");

/***********
 * DEFINE ALL VARIABLES
 ***********/
define(FILE_NAME, "E:/scaffold4php/config/config.xml");


/***********
 * INSTANTIATE ALL OBJECTS
 ***********/
$DOM          = new DomDocument();
$DB           = new DB();
$ClassFactory = new ClassFactory();

/***********
 * CREAT DOM OBJECT AND GET PROPERTIES
 ***********/
if(!file_exists(FILE_NAME)){
	echo "The file ".FILE_NAME." does not exist.";
	exit();
}

if($DOM->load(FILE_NAME)){

	$dbTypes     = $DOM->getElementsByTagName("db_type");
	$dbHosts     = $DOM->getElementsByTagName("db_host");
	$dbNames     = $DOM->getElementsByTagName("db_name");
	$dbUserNames = $DOM->getElementsByTagName("db_username");
	$dbPasswords = $DOM->getElementsByTagName("db_password");

	// Get the DB Type
	foreach($dbTypes as $type){
		$dbType = $type->nodeValue;
	}
	
	//Get the DB Host
	foreach($dbHosts as $host){
		$dbHost = $host->nodeValue;
	}
	
	//Get the DB Name
	foreach($dbNames as $name){
		$dbName = $name->nodeValue;
	}
	
	//Get the DB UserName
	foreach($dbUserNames as $name){
		$dbUserName = $name->nodeValue;
	}
	
	//Get the DB Passwords
	foreach($dbPasswords as $pass){
		$dbPassword = $pass->nodeValue;
	}
	
}else{
	echo "Error opening ".FILE_NAME;
	exit();
}


/**********
 * CONNECT TO DB
 *********/
$connectionString = array(
						    'phptype'  => $dbType,
						    'hostspec' => $dbHost,
						    'database' => $dbName,
						    'username' => $dbUserName,
						    'password' => $dbPassword
						);

$db = DB::connect($connectionString);
if(PEAR::isError($db)){
	echo "Could not connect to requested database<br>";
	//print_r($db);  //Uncomment for debugging
	exit();
}


/**********
 * GET ALL TABLE ATTRIBUTES
 **********/
$tables = $db->getListOf('tables');
if(PEAR::isError($db)){
	echo "Could capture database tables.<br>";
	//print_r($db);  //Uncomment for debugging
	exit();
}
 
/**********
 * FOREACH TABLE CREATE CRUD
 **********/
foreach($tables as $table){

   // GET THE TABLE NAME
	$tableName    =  $table;
	
	// CAPTURE THE TABLE INFORMATION
	 $tableInfo = $db->tableInfo($tableName);
	
	//print_r($tableInfo);  //Uncomment for debugging
	
	// CREATE THE DAO.
	$ClassFactory->create($tableName, $tableInfo);
	

}//End foreach
?>
